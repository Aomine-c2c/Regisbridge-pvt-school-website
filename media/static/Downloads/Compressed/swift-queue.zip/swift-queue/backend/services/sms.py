
def send_sms(phone: str, message: str) -> None:
    # Mock SMS sender: replace with real provider (e.g., Twilio) later
    print(f"[MOCK SMS] -> {phone}: {message}")
