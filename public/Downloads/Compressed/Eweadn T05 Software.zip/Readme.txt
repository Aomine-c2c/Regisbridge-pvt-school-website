The language of Setup cannot be changed... Just Select Mid Options (you may have to run setup twice)

Requirements:
Eweadn T05 Working Mouse
Windows 10

Just install the software and configure your Mouse according to it...

Moreover Subscribe to this channel https://youtube.com/c/J3rRyReD